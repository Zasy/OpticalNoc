/*
 *  global_data.h
 *  test
 *
 *  Created by yao on 09-8-5.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
#ifndef global_data
#define global_data

//ofstream send_req_out_log;
//ofstream send_req_out_log_2;
int trafficname;
double injection_rate;
int simulation_time;

ofstream routing_list_log;
ofstream trace_list_log;
ofstream loss_list_log;
ofstream power_list_log;
ofstream performance_log;
#endif

